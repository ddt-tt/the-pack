// background.js のイメージ
chrome.tabs.onCreated.addListener((tab) => {
  // 現在のウィンドウのタブを全て取得
  chrome.tabs.query({ currentWindow: true }, (tabs) => {
    
    // タブが6個以上になったら発動！
    if (tabs.length >= 6) {
      // 例：ランダムなタブを1つ選んで閉じる
      const randomIndex = Math.floor(Math.random() * tabs.length);
      const tabToKill = tabs[randomIndex];
      
      chrome.tabs.remove(tabToKill.id);
      console.log("💥 6タブに達したため、1つのタブが犠牲になりました");
    }
  });
});